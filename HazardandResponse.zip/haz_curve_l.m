function [Sa,lf]=haz_curve_l(Tm,l,S,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y,flag)
if flag==1
    lf=1;
    if Tm<0.2
       Sa_PGA=interp1(PGAy,PGAx,l);
       Sa_02=interp1(SA02y,SA02x,l);
       Sa=interp1([0,0.2],[Sa_PGA,Sa_02],Tm);
    elseif Tm>=0.2 && Tm<0.7
       Sa=interp1(SA02y,SA02x,l);
    else
       Sa=interp1(SA1y,SA1x/Tm,l);
    end
else
    Sa=1;
    if Tm<0.2
       l_PGA=interp1(PGAx,PGAy,S);
       l_02=interp1(SA02x,SA02y,S);
       lf=interp1([0,0.2],[l_PGA,l_02],Tm);
    elseif Tm>=0.2 && Tm<0.7
       lf=interp1(SA02x,SA02y,S);
    else
       lf=interp1(SA1x/Tm,SA1y,S);
    end
end

end
